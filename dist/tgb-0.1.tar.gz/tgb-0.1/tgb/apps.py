from django.apps import AppConfig


class TgbConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tgb'
